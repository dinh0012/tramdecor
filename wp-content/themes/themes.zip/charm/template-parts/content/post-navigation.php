<div class="btn_next_page_blog">
    <?php echo previous_post_link( '<div class="btn_p_blog">%link</div>', '<i class="fa fa-angle-double-left" aria-hidden="true"></i> Review</a>' ); ?>
    <?php echo next_post_link( '<div class="btn_p_blog">%link</div>', 'Next <i class="fa fa-angle-double-right" aria-hidden="true"></i> </a>' ); ?>
</div>