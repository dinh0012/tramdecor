<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="wth_theme_main">
	<!--	<div class="container">
			<div class="row">-->
				<?php
					the_content();
				?>
	<!--		</div>
		</div>-->
	</div><!-- .entry-content -->
</article><!-- #post-## -->
