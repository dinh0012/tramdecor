<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Smart Blog
 * @since 1.0
 */
?>

<?php dynamic_sidebar( 'primary-sidebar' ); ?>